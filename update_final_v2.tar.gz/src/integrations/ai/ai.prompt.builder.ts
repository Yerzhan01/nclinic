import { prisma } from '@/config/prisma.js';
import { logger } from '@/common/utils/logger.js';
import { aiABTestService } from './ai.ab-test.service.js';
import { aiSummaryService } from './ai.summary.service.js';
import { ragService } from '@/modules/rag/rag.service.js';
import { buildPatientContext } from '@/common/utils/buildPatientContext.js';
import type { Message } from '@prisma/client';
import type { PatientProfile } from '@/modules/patients/patient-profile.schema.js';

// Default system prompt if no variants configured
const DEFAULT_SYSTEM_PROMPT = `Ты — профессиональный ассистент для пациентов программы похудения.

Твои задачи:
- Отвечать на вопросы о программе, питании, режиме
- Поддерживать мотивацию пациента
- Напоминать о важных моментах программы
- Если вопрос вне твоей компетенции — предложи связаться с менеджером

Правила:
- Отвечай кратко и по делу (1-3 предложения)
- Будь дружелюбным и поддерживающим
- Не давай медицинских советов
- Используй информацию из базы знаний`;

const DEFAULT_STYLE_GUIDE = `Стиль общения:
- Используй эмодзи умеренно
- Обращайся на "вы"
- Если пациент расстроен — посочувствуй
- Завершай сообщение вопросом или призывом к действию`;

interface PromptBuildResult {
    prompt: string;
    variantId: string | null;
}

export class AIPromptBuilder {
    /**
     * Build full prompt for AI response generation
     */
    async buildPrompt(patientId: string, recentMessages: Message[]): Promise<PromptBuildResult> {
        // Get patient data with active program
        const patient = await prisma.patient.findUnique({
            where: { id: patientId },
        });

        if (!patient) {
            throw new Error(`Patient not found: ${patientId}`);
        }

        // Get active program separately
        const activeProgram = await prisma.programInstance.findFirst({
            where: {
                patientId,
                status: 'ACTIVE',
            },
            include: { template: true },
        });

        // Select prompt variant (A/B testing)
        const variant = await aiABTestService.selectVariant();
        const systemPrompt = variant?.systemPrompt || DEFAULT_SYSTEM_PROMPT;
        const styleGuide = variant?.styleGuide || DEFAULT_STYLE_GUIDE;

        // Get conversation summary
        const summary = await aiSummaryService.getSummary(patientId);

        // Get RAG context from last user message
        const lastUserMessage = recentMessages.filter(m => m.sender === 'PATIENT').pop();
        const ragContext = lastUserMessage?.content
            ? await ragService.search(lastUserMessage.content, 3)
            : [];

        // Build patient context from profile JSON
        const patientProfile = patient.profile as PatientProfile | null;
        const patientContext = buildPatientContext(patientProfile);

        // Calculate program day
        let programInfo = 'Программа не назначена';
        if (activeProgram) {
            const startDate = activeProgram.startDate;
            const dayNumber = Math.ceil((Date.now() - startDate.getTime()) / (1000 * 60 * 60 * 24));
            programInfo = `${activeProgram.template.name}, день ${dayNumber} из ${activeProgram.template.durationDays}`;
        }

        // Format recent messages
        const formattedMessages = recentMessages.slice(-10).map(m => {
            const sender = m.sender === 'PATIENT' ? patient.fullName : m.sender;
            const content = m.content || '[медиа]';
            return `[${sender}]: ${content}`;
        }).join('\n');

        // Format RAG context
        const ragContextStr = ragContext.length > 0
            ? ragContext.map(r => `- ${r.content}`).join('\n')
            : 'Релевантной информации не найдено.';

        // Build final prompt
        const prompt = `${systemPrompt}

${styleGuide}

=== ПРОФИЛЬ ПАЦИЕНТА ===
Имя: ${patient.fullName}
Программа: ${programInfo}
${patientContext ? patientContext : ''}

=== ИСТОРИЯ (сжато) ===
${summary || 'Новый диалог, истории нет.'}

=== ПОСЛЕДНИЕ СООБЩЕНИЯ ===
${formattedMessages}

=== БАЗА ЗНАНИЙ (релевантная информация) ===
${ragContextStr}

=== ЗАДАЧА ===
Ответь на последнее сообщение пациента.
Если требуется помощь специалиста или запрос вне твоей компетенции, в конце ответа добавь: [HANDOFF_REQUIRED]`;

        logger.debug({
            patientId,
            variantId: variant?.id,
            hasSummary: !!summary,
            ragContextCount: ragContext.length,
        }, 'Prompt built');

        return {
            prompt,
            variantId: variant?.id || null,
        };
    }
}

export const aiPromptBuilder = new AIPromptBuilder();
