-- AlterTable
ALTER TABLE "patients" ADD COLUMN     "timezone" TEXT NOT NULL DEFAULT 'Asia/Almaty';
