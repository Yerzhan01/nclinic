'use client';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/api';
import type { ApiResponse, Patient, ProgramTemplate } from '@/types/api';

export function usePatients(search?: string) {
    return useQuery({
        queryKey: ['patients', search],
        queryFn: async () => {
            const params = search ? `?search=${encodeURIComponent(search)}` : '';
            const response = await api.get<ApiResponse<Patient[]>>(`/patients${params}`);
            return response.data.data || [];
        },
    });
}

export function usePatient(id: string) {
    return useQuery({
        queryKey: ['patient', id],
        queryFn: async () => {
            const response = await api.get<ApiResponse<Patient>>(`/patients/${id}`);
            return response.data.data;
        },
        enabled: !!id,
    });
}

export function useCreatePatient() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async (data: { fullName: string; phone: string; templateId?: string }) => {
            const response = await api.post<ApiResponse<Patient>>('/patients', data);
            return response.data.data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['patients'] });
        },
    });
}

export function useUpdatePatient() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async ({ id, data }: { id: string; data: Partial<Patient> }) => {
            const response = await api.patch<ApiResponse<Patient>>(`/patients/${id}`, data);
            return response.data.data;
        },
        onSuccess: (_, variables) => {
            queryClient.invalidateQueries({ queryKey: ['patient', variables.id] });
            queryClient.invalidateQueries({ queryKey: ['patients'] });
        },
    });
}

export function useProgramTemplates() {
    return useQuery({
        queryKey: ['program-templates'],
        queryFn: async () => {
            const response = await api.get<ApiResponse<ProgramTemplate[]>>('/programs/templates');
            return response.data.data || [];
        },
    });
}
