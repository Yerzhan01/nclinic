-- AlterTable
ALTER TABLE "messages" ADD COLUMN     "media_type" TEXT;
