import { PrismaClient, UserRole } from '@prisma/client';
import type { ProgramTemplateRules } from '@/modules/programs/program.types.js';

const prisma = new PrismaClient();

async function main() {
    console.log('🌱 Starting seed...');

    // 1. Create Admin User
    const adminEmail = 'admin@nclinic.kz';
    const existingAdmin = await prisma.user.findUnique({ where: { email: adminEmail } });

    if (!existingAdmin) {
        await prisma.user.create({
            data: {
                email: adminEmail,
                passwordHash: '$2b$10$EpI/yL.F.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q.Q', // Dummy hash
                fullName: 'System Administrator',
                role: UserRole.ADMIN,
            },
        });
        console.log('✅ Admin user created');
    }

    // 2. Create Default Clinic
    const clinicName = 'Main Clinic';
    const existingClinic = await prisma.clinic.findFirst({ where: { name: clinicName } });
    let clinicId = existingClinic?.id;

    if (!existingClinic) {
        const clinic = await prisma.clinic.create({
            data: {
                name: clinicName,
                isActive: true
            }
        });
        clinicId = clinic.id;
        console.log('✅ Default Clinic created');
    }

    // 3. Create Default Program Template with Dynamic Rules
    const templateName = 'Default Weight Loss Program';
    const existingTemplate = await prisma.programTemplate.findFirst({
        where: { name: templateName }
    });

    // Define the dynamic schedule rules
    const programRules: ProgramTemplateRules = {
        schedule: [
            // DAY 1
            {
                day: 1,
                activities: [
                    {
                        slot: 'MORNING',
                        time: '09:00',
                        type: 'WEIGHT',
                        question: 'Доброе утро! Начинаем нашу программу. Пожалуйста, взвесьтесь и отправьте ваш текущий вес (в кг).',
                        required: true
                    },
                    {
                        slot: 'EVENING',
                        time: '20:00',
                        type: 'MOOD',
                        question: 'Как прошел ваш первый день? Оцените ваше самочувствие и настроение.',
                        required: true
                    }
                ]
            },
            // DAY 2
            {
                day: 2,
                activities: [
                    {
                        slot: 'MORNING',
                        time: '10:00',
                        type: 'DIET_ADHERENCE',
                        question: 'Доброе утро! Удалось ли вчера придерживаться плана питания?',
                        required: false
                    }
                ]
            },
            // DAY 3
            {
                day: 3,
                activities: [
                    {
                        slot: 'MORNING',
                        time: '14:00',
                        type: 'STEPS',
                        question: 'Половина дня прошла! Сколько шагов вы уже сделали?',
                        required: false
                    }
                ]
            },
            // DAY 7 (Weekly Check)
            {
                day: 7,
                activities: [
                    {
                        slot: 'MORNING',
                        time: '09:00',
                        type: 'WEIGHT',
                        question: 'Прошла неделя! Пожалуйста, отправьте ваш контрольный вес.',
                        required: true
                    },
                    {
                        slot: 'AFTERNOON',
                        time: '14:00',
                        type: 'VISIT' as any, // Cast as any if Type is not updated in seed context yet
                        question: 'Напоминаем, что завтра у вас запланирован визит в клинику. Вы придете?',
                        required: false
                    }
                ]
            }
        ]
    };

    if (!existingTemplate) {
        await prisma.programTemplate.create({
            data: {
                name: templateName,
                durationDays: 42,
                slotsPerDay: ['MORNING', 'AFTERNOON', 'EVENING'],
                isActive: true,
                rules: programRules as any // Store as JSON
            }
        });
        console.log('✅ Default Program Template created');
    } else {
        // Update existing template rules
        await prisma.programTemplate.update({
            where: { id: existingTemplate.id },
            data: {
                rules: programRules as any
            }
        });
        console.log('✅ Default Program Template updated with new rules');
    }

    // 3. Create dummy patient for testing
    const demoPhone = '77010000000';
    const existingPatient = await prisma.patient.findUnique({ where: { phone: demoPhone } });

    if (!existingPatient) {
        await prisma.patient.create({
            data: {
                fullName: 'Demo Patient',
                phone: demoPhone,
                timezone: 'Asia/Almaty',
                clinicId: clinicId // Assign to default clinic
            }
        });
        console.log('✅ Demo Patient created');
    }

    console.log('🏁 Seed completed');
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
