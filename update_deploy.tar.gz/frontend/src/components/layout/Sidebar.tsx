'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
    Users,
    AlertTriangle,
    CheckSquare,
    Settings,
    LayoutDashboard,
    Sparkles,
    BarChart2,
} from 'lucide-react';

const navigation = [
    { name: 'Дашборд', href: '/', icon: LayoutDashboard },
    { name: 'Пациенты', href: '/patients', icon: Users },
    { name: 'Алерты', href: '/alerts', icon: AlertTriangle },
    { name: 'Задачи', href: '/tasks', icon: CheckSquare },
    { name: 'Аналитика', href: '/analytics', icon: BarChart2 },
    { name: 'Интеграции', href: '/integrations', icon: Settings },
    { name: 'Программы', href: '/settings/programs', icon: Settings },
    { name: 'AI Настройки', href: '/settings/ai', icon: Sparkles },
];

export function Sidebar() {
    const pathname = usePathname();

    return (
        <aside className="fixed left-0 top-0 z-40 h-screen w-64 border-r bg-background">
            <div className="flex h-16 items-center border-b px-6">
                <Link href="/" className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                        <span className="text-primary-foreground font-bold text-sm">NC</span>
                    </div>
                    <span className="font-semibold text-lg">N-Clinic</span>
                </Link>
            </div>

            <nav className="flex flex-col gap-1 p-4">
                {navigation.map((item) => {
                    const isActive =
                        pathname === item.href ||
                        (item.href !== '/' && pathname.startsWith(item.href));

                    return (
                        <Link
                            key={item.name}
                            href={item.href}
                            className={cn(
                                'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                                isActive
                                    ? 'bg-primary text-primary-foreground'
                                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                            )}
                        >
                            <item.icon className="h-5 w-5" />
                            {item.name}
                        </Link>
                    );
                })}
            </nav>
        </aside>
    );
}
