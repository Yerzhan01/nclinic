
'use client';

import { useQuery } from '@tanstack/react-query';
import { systemApi, SystemLog } from '@/api/system.api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';
import { Activity } from 'lucide-react';

export default function LogsPage() {
    // Poll logs every 5 seconds
    const { data: logs, isLoading: loadingLogs } = useQuery({
        queryKey: ['system-logs'],
        queryFn: () => systemApi.getLogs({ limit: 50 }),
        refetchInterval: 5000
    });

    // Poll status every 10 seconds
    const { data: status, isLoading: loadingStatus } = useQuery({
        queryKey: ['system-status'],
        queryFn: systemApi.getStatus,
        refetchInterval: 10000
    });

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-3xl font-bold tracking-tight">Системные логи</h1>

                {/* Status Badge */}
                <div className="flex items-center gap-4">
                    {loadingStatus ? (
                        <Badge variant="outline">Загрузка...</Badge>
                    ) : (
                        <>
                            <div className="flex items-center gap-2">
                                <span className="text-sm text-muted-foreground">DB:</span>
                                <Badge variant={status?.services.database.status === 'UP' ? 'outline' : 'destructive'} className={status?.services.database.status === 'UP' ? 'border-green-500 text-green-600' : ''}>
                                    {status?.services.database.latency}ms
                                </Badge>
                            </div>
                            <div className="flex items-center gap-2">
                                <span className="text-sm text-muted-foreground">Redis:</span>
                                <Badge variant={status?.services.redis.status === 'UP' ? 'outline' : 'destructive'} className={status?.services.redis.status === 'UP' ? 'border-green-500 text-green-600' : ''}>
                                    {status?.services.redis.latency}ms
                                </Badge>
                            </div>
                            <Badge variant={status?.status === 'ONLINE' ? 'outline' : 'destructive'} className={`text-lg px-4 py-1 ${status?.status === 'ONLINE' ? 'border-green-500 text-green-600 bg-green-50 dark:bg-green-900/20' : ''}`}>
                                {status?.status === 'ONLINE' ? 'ONLINE' : 'OFFLINE'}
                            </Badge>
                        </>
                    )}
                </div>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Activity className="h-5 w-5" />
                        Последние 50 событий
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="rounded-md border">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead className="w-[180px]">Время</TableHead>
                                    <TableHead className="w-[100px]">Уровень</TableHead>
                                    <TableHead className="w-[120px]">Категория</TableHead>
                                    <TableHead>Сообщение</TableHead>
                                    <TableHead className="w-[200px]">Мета</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {loadingLogs ? (
                                    <TableRow>
                                        <TableCell colSpan={5} className="text-center h-24">Загрузка...</TableCell>
                                    </TableRow>
                                ) : logs?.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={5} className="text-center h-24">Логов пока нет</TableCell>
                                    </TableRow>
                                ) : (
                                    logs?.map((log: SystemLog) => (
                                        <TableRow key={log.id}>
                                            <TableCell className="font-medium">
                                                {format(new Date(log.createdAt), 'HH:mm:ss dd.MM', { locale: ru })}
                                            </TableCell>
                                            <TableCell>
                                                <Badge
                                                    variant={
                                                        log.level === 'ERROR' ? 'destructive' :
                                                            log.level === 'WARN' ? 'secondary' :
                                                                'secondary'
                                                    }
                                                    className={log.level === 'WARN' ? 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-100' : ''}
                                                >
                                                    {log.level}
                                                </Badge>
                                            </TableCell>
                                            <TableCell>
                                                <Badge variant="outline">{log.category}</Badge>
                                            </TableCell>
                                            <TableCell>{log.message}</TableCell>
                                            <TableCell className="text-xs text-muted-foreground font-mono truncate max-w-[200px]">
                                                {log.meta ? JSON.stringify(log.meta) : '-'}
                                            </TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
