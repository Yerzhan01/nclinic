import { prisma } from '@/config/prisma.js';
import { logger } from '@/common/utils/logger.js';
import { AI_SYSTEM_PROMPT_TEMPLATE, USER_MESSAGE_TEMPLATE } from './ai.prompts.js';
import { buildPatientContext } from '@/common/utils/buildPatientContext.js';
import { ragService } from '@/modules/rag/rag.service.js';
import { taskService } from '@/modules/tasks/task.service.js';
import { TaskType, TaskPriority, TaskSource } from '@prisma/client';
import type { AIConfig, AIAnalysisResult, AIConnectionStatus } from './ai.types.js';
import { DEFAULT_AGENT_SETTINGS } from './ai.types.js';
import type { PatientProfile } from '@/modules/patients/patient-profile.schema.js';
import { systemLogService } from '@/modules/system/system-log.service.js';

// Max context length to prevent token overflow
const MAX_CONTEXT_LENGTH = 1200;

export class AIService {

    /**
     * Get AI config from IntegrationSettings
     */
    async getConfig(): Promise<AIConfig | null> {
        const settings = await prisma.integrationSettings.findUnique({
            where: { type: 'ai' },
        });

        if (!settings || !settings.isEnabled) {
            return null;
        }

        const config = settings.config as unknown as AIConfig;
        return config;
    }

    /**
     * Save AI config to IntegrationSettings
     */
    async saveConfig(config: AIConfig): Promise<void> {
        await prisma.integrationSettings.upsert({
            where: { type: 'ai' },
            update: {
                config: config as object,
                isEnabled: true,
            },
            create: {
                type: 'ai',
                config: config as object,
                isEnabled: true,
            },
        });
    }

    /**
     * Get full AI settings for Control Center
     */
    async getSettings(): Promise<AIConfig | null> {
        return this.getConfig();
    }

    /**
     * Update AI settings from Control Center
     */
    async updateSettings(partial: Partial<AIConfig>): Promise<AIConfig> {
        const current = await this.getConfig();
        const merged: AIConfig = {
            apiKey: partial.apiKey ?? current?.apiKey ?? '',
            model: partial.model ?? current?.model ?? 'gpt-4o-mini',
            temperature: partial.temperature ?? current?.temperature,
            messageBufferSeconds: partial.messageBufferSeconds ?? current?.messageBufferSeconds ?? 10,
            agent: {
                ...DEFAULT_AGENT_SETTINGS,
                ...current?.agent,
                ...partial.agent
            },
            rag: {
                ...current?.rag,
                ...partial.rag
            },
        };
        logger.info({ partial, merged }, 'Updating AI settings');
        await this.saveConfig(merged);
        return merged;
    }

    /**
     * Get connection status
     */
    async getStatus(): Promise<AIConnectionStatus> {
        const config = await this.getConfig();

        if (!config) {
            return { isEnabled: false, status: 'disconnected' };
        }

        try {
            await this.testConnection(config);
            return {
                isEnabled: true,
                status: 'connected',
                model: config.model,
            };
        } catch (error) {
            const err = error as Error;
            return {
                isEnabled: true,
                status: 'error',
                model: config.model,
                error: err.message,
            };
        }
    }

    /**
     * Test connection to OpenAI
     */
    private async testConnection(config: AIConfig): Promise<void> {
        const response = await fetch('https://api.openai.com/v1/models', {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${config.apiKey}`,
            },
        });

        if (!response.ok) {
            throw new Error(`OpenAI API error: ${response.status}`);
        }
    }

    /**
     * Check if text contains any trigger words (case-insensitive)
     */
    private containsTrigger(text: string, triggers: string[]): boolean {
        const lowerText = text.toLowerCase();
        return triggers.some(trigger => lowerText.includes(trigger.toLowerCase()));
    }

    /**
     * Analyze message using OpenAI
     */
    async analyzeMessage(text: string, patientId: string): Promise<AIAnalysisResult | null> {
        const config = await this.getConfig();

        if (!config) {
            logger.warn('AI not configured, skipping analysis');
            return null;
        }

        const patientProfile = await this.getPatientProfile(patientId);

        // Build patient context
        let patientContext = '';
        let hasContext = false;
        if (patientProfile && Object.keys(patientProfile).length > 0) {
            patientContext = buildPatientContext(patientProfile);
            if (patientContext.length > MAX_CONTEXT_LENGTH) {
                patientContext = patientContext.substring(0, MAX_CONTEXT_LENGTH) + '...[обрезано]';
            }
            hasContext = true;
        }

        const agentSettings = config.agent ?? DEFAULT_AGENT_SETTINGS;

        // Check handoff triggers BEFORE calling OpenAI (fast path)
        const triggers = agentSettings.handoffTriggers ?? DEFAULT_AGENT_SETTINGS.handoffTriggers ?? [];
        if (triggers.length > 0 && this.containsTrigger(text, triggers)) {
            logger.info({ patientId, triggers }, 'Handoff trigger detected, instant handoff');
            return {
                sentiment: 'neutral',
                riskLevel: 'HIGH',
                summary: 'Обнаружены стоп-слова/тревожные жалобы',
                shouldReply: false,
                handoffRequired: true,
            };
        }

        // RAG Search
        let ragContext = '';
        let ragStats = { docs: 0, chars: 0 };

        if (config.rag?.enabled) {
            try {
                const results = await ragService.search(
                    text,
                    config.rag.topK ?? 3,
                    config.rag.maxChars ?? 2000
                );

                if (results.length > 0) {
                    ragContext = ragService.buildRagContext(results);
                    ragStats = { docs: results.length, chars: ragContext.length };
                    logger.info({ patientId, ...ragStats }, 'RAG context added to prompt');
                }
            } catch (err) {
                logger.error({ err }, 'RAG search failed, proceeding without context');
            }
        }

        // Fetch Rich Context
        const history = await this.getConversationHistory(patientId);
        const programInfo = await this.getProgramStatus(patientId);
        const tasks = await this.getOpenTasks(patientId);

        try {
            const systemPrompt = AI_SYSTEM_PROMPT_TEMPLATE(
                patientContext,
                agentSettings,
                ragContext,
                history,
                programInfo,
                tasks
            );

            const requestBody: Record<string, unknown> = {
                model: config.model,
                temperature: config.temperature ?? 0.2,
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: USER_MESSAGE_TEMPLATE(text) },
                ],
                response_format: { type: 'json_object' },
            };

            // Add max_tokens if configured
            if (agentSettings.maxOutputTokens) {
                requestBody.max_tokens = agentSettings.maxOutputTokens;
            }

            const response = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${config.apiKey}`,
                },
                body: JSON.stringify(requestBody),
            });

            if (!response.ok) {
                const errorText = await response.text();
                logger.error({ status: response.status, error: errorText }, 'OpenAI API error');
                return null;
            }

            const data = (await response.json()) as {
                choices?: Array<{ message?: { content?: string } }>;
            };

            const content = data.choices?.[0]?.message?.content;

            if (!content) {
                logger.error('OpenAI returned empty content');
                return null;
            }

            // Parse and validate JSON response
            let analysis = this.parseAnalysis(content);

            // Check forbidden phrases AFTER getting response
            const forbidden = agentSettings.forbiddenPhrases ?? [];
            if (forbidden.length > 0 && analysis.suggestedReply && this.containsTrigger(analysis.suggestedReply, forbidden)) {
                logger.warn({ patientId }, 'Forbidden phrase detected in AI response, forcing handoff');
                analysis = {
                    ...analysis,
                    shouldReply: false,
                    handoffRequired: true,
                    riskLevel: 'MEDIUM',
                    suggestedReply: undefined,
                };
            }

            // Post-process suggestedReply
            if (analysis.suggestedReply) {
                analysis.suggestedReply = this.postProcessSuggestedReply(
                    analysis.suggestedReply,
                    agentSettings.maxSentences ?? 6,
                    1200 // maxChars
                );
            }

            // PHASE 17: Trigger Task Creation (Synchronous)
            try {
                if (analysis.riskLevel === 'HIGH' || analysis.riskLevel === 'CRITICAL') {
                    await taskService.createTask({
                        patientId,
                        type: TaskType.RISK_ALERT,
                        priority: TaskPriority.HIGH,
                        title: 'Тревожный сигнал от пациента (AI)',
                        description: `AI обнаружил высокий риск: ${analysis.riskLevel}. Summary: ${analysis.summary}`,
                        source: TaskSource.AI,
                        meta: { riskLevel: analysis.riskLevel, summary: analysis.summary }
                    });
                } else if (analysis.handoffRequired) {
                    await taskService.createTask({
                        patientId,
                        type: TaskType.FOLLOW_UP,
                        priority: TaskPriority.MEDIUM,
                        title: 'Пациент просит человека (AI)',
                        description: `Запрос на переключение оператора. Summary: ${analysis.summary}`,
                        source: TaskSource.AI,
                        meta: { summary: analysis.summary }
                    });
                }
            } catch (taskError) {
                logger.error({ error: taskError, patientId }, 'Failed to create AI task');
                // Don't fail the whole analysis
            }

            // Enhanced logging
            logger.info(
                {
                    patientId,
                    riskLevel: analysis.riskLevel,
                    shouldReply: analysis.shouldReply,
                    handoffRequired: analysis.handoffRequired,
                },
                'AI analysis completed'
            );

            await systemLogService.create('INFO', 'AI', 'Analysis completed', {
                patientId,
                risk: analysis.riskLevel,
                reply: analysis.shouldReply
            });

            return analysis;
        } catch (error) {
            logger.error({ error, patientId }, 'AI analysis error');
            await systemLogService.create('ERROR', 'AI', 'Analysis Failed', { error: (error as Error).message });
            return null;
        }
    }

    private async getPatientProfile(patientId: string): Promise<PatientProfile | null> {
        const patient = await prisma.patient.findUnique({
            where: { id: patientId },
            select: { profile: true }
        });
        return patient?.profile as PatientProfile || null;
    }

    /**
     * Post-process suggestedReply to enforce maxSentences and maxChars
     * Guarantees consistent UX even if LLM generates too much
     */
    private postProcessSuggestedReply(text: string, maxSentences: number, maxChars: number): string {
        let result = text.trim();

        // Truncate by max chars first
        if (result.length > maxChars) {
            result = result.substring(0, maxChars);
            // Try to end at last complete sentence
            const lastSentenceEnd = Math.max(
                result.lastIndexOf('.'),
                result.lastIndexOf('!'),
                result.lastIndexOf('?')
            );
            if (lastSentenceEnd > maxChars * 0.5) {
                result = result.substring(0, lastSentenceEnd + 1);
            } else {
                result = result + '...';
            }
        }

        // Truncate by max sentences
        const sentences = result.split(/(?<=[.!?])\s+/);
        if (sentences.length > maxSentences) {
            result = sentences.slice(0, maxSentences).join(' ');
        }

        return result.trim();
    }

    /**
     * Toggle AI pause status for a patient
     */
    async togglePatientAI(patientId: string, pause: boolean, staffId?: string, reason?: string): Promise<void> {
        await prisma.patient.update({
            where: { id: patientId },
            data: {
                aiPaused: pause,
                aiPausedAt: pause ? new Date() : null,
                aiPausedBy: pause ? (staffId ?? 'staff') : null,
                aiPauseReason: pause ? reason : null,
            },
        });
        logger.info({ patientId, aiPaused: pause, staffId }, 'Patient AI status toggled');
    }

    /**
     * Get AI pause status for a patient
     */
    async getPatientAIStatus(patientId: string): Promise<{ aiPaused: boolean; aiPausedAt?: Date; aiPausedBy?: string }> {
        const patient = await prisma.patient.findUnique({
            where: { id: patientId },
            select: { aiPaused: true, aiPausedAt: true, aiPausedBy: true }
        });
        return {
            aiPaused: patient?.aiPaused ?? false,
            aiPausedAt: patient?.aiPausedAt ?? undefined,
            aiPausedBy: patient?.aiPausedBy ?? undefined,
        };
    }

    /**
     * Parse and validate AI response
     */
    private parseAnalysis(content: string): AIAnalysisResult {
        try {
            const parsed = JSON.parse(content);

            return {
                sentiment: this.validateSentiment(parsed.sentiment),
                riskLevel: this.validateRiskLevel(parsed.riskLevel),
                summary: String(parsed.summary || 'No summary'),
                shouldReply: Boolean(parsed.shouldReply),
                suggestedReply: parsed.suggestedReply ? String(parsed.suggestedReply) : undefined,
                handoffRequired: Boolean(parsed.handoffRequired),
                checkInSatisfied: Boolean(parsed.checkInSatisfied),
            };
        } catch (error) {
            logger.error({ error, content }, 'Failed to parse AI response');
            return {
                sentiment: 'neutral',
                riskLevel: 'MEDIUM',
                summary: 'Failed to analyze',
                shouldReply: false,
                handoffRequired: true,
            };
        }
    }

    private validateSentiment(value: unknown): 'positive' | 'neutral' | 'negative' {
        if (value === 'positive' || value === 'neutral' || value === 'negative') {
            return value;
        }
        return 'neutral';
    }

    private validateRiskLevel(value: unknown): 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' {
        if (value === 'LOW' || value === 'MEDIUM' || value === 'HIGH' || value === 'CRITICAL') {
            return value;
        }
        return 'MEDIUM';
    }
    async generateCheckInSummary(
        patientId: string,
        checkIns: any[] // Using any[] to avoid circular dependency issues for now, or import CheckIn type if safe
    ): Promise<{
        progress: string;
        issues: string[];
        nextStep: string;
        tone: 'encouraging' | 'neutral' | 'concerned';
    }> {
        const config = await this.getConfig();
        if (!config) {
            return {
                progress: 'AI not configured',
                issues: [],
                nextStep: 'Check in manually',
                tone: 'neutral',
            };
        }

        const context = checkIns.map(c =>
            `- ${new Date(c.createdAt).toLocaleDateString()}: [${c.type}] ${c.valueText || c.valueNumber || (c.valueBool ? 'Yes' : 'No')}`
        ).join('\n');

        const prompt = `
        Analyze the following recent patient check-ins and generate a summary.
        
        Check-ins:
        ${context}

        Return JSON format:
        {
            "progress": "Brief summary of progress (1-2 sentences)",
            "issues": ["List of potential issues or areas of concern"],
            "nextStep": "One clear actionable next step for the patient",
            "tone": "encouraging" | "neutral" | "concerned"
        }
        `;

        try {
            const response = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${config.apiKey}`,
                },
                body: JSON.stringify({
                    model: config.model,
                    messages: [{ role: 'user', content: prompt }],
                    response_format: { type: 'json_object' },
                }),
            });

            if (!response.ok) throw new Error('AI request failed');

            const data = (await response.json()) as { choices: { message: { content: string } }[] };
            const content = data.choices[0].message.content;
            return JSON.parse(content);
        } catch (error) {
            logger.error({ error, patientId }, 'Failed to generate check-in summary');
            return {
                progress: 'Unable to generate summary',
                issues: ['AI service error'],
                nextStep: 'Contact support',
                tone: 'neutral',
            };
        }
    }
    async transcribeAudio(audioUrl: string): Promise<string | null> {
        const config = await this.getConfig();
        if (!config) return null;

        try {
            // Fetch audio file
            const audioRes = await fetch(audioUrl);
            if (!audioRes.ok) {
                logger.warn({ audioUrl, status: audioRes.status }, 'Failed to fetch audio for transcription');
                return null;
            }

            const arrayBuffer = await audioRes.arrayBuffer();
            const buffer = Buffer.from(arrayBuffer);

            // Create a File-like object for FormData
            // In Node 20, global File exists, but let's be robust
            const blob = new Blob([buffer], { type: 'audio/ogg' });
            const file = new File([blob], 'audio.ogg', { type: 'audio/ogg' });

            const formData = new FormData();
            formData.append('file', file);
            formData.append('model', 'whisper-1');

            const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
                method: 'POST',
                headers: {
                    Authorization: `Bearer ${config.apiKey}`,
                },
                body: formData,
            });

            if (!response.ok) {
                const err = await response.text();
                logger.error({ error: err }, 'Whisper API failed');
                return null;
            }

            const data = await response.json() as { text: string };
            logger.info({ text: data.text }, 'Audio transcription completed');
            return data.text;
        } catch (error) {
            logger.error({ error }, 'Audio transcription error');
            return null;
        }
    }

    /**
     * Get recent conversation history formatted for AI
     */
    private async getConversationHistory(patientId: string): Promise<string> {
        try {
            const messages = await prisma.message.findMany({
                where: { patientId },
                orderBy: { createdAt: 'desc' },
                take: 30, // Last 30 messages
            });

            // Reverse to chrono order
            const history = messages.reverse().map(m => {
                const role = m.sender === 'PATIENT' ? 'Пациент' : (m.sender === 'AI' ? 'AI' : 'Сотрудник');
                const time = new Date(m.createdAt).toLocaleString('ru-RU', { hour: '2-digit', minute: '2-digit' });
                return `[${time}] ${role}: ${m.content || '[Медиа файл]'}`;
            }).join('\n');

            return history;
        } catch (e) {
            return '';
        }
    }

    /**
     * Get active program status
     */
    private async getProgramStatus(patientId: string): Promise<string> {
        try {
            const program = await prisma.programInstance.findFirst({
                where: { patientId, status: 'ACTIVE' },
                include: { template: true }
            });

            if (!program) return 'Нет активной программы.';

            // Get check-ins for today
            const startOfDay = new Date();
            startOfDay.setHours(0, 0, 0, 0);

            const checks = await prisma.checkIn.findMany({
                where: { patientId, createdAt: { gte: startOfDay } }
            });

            const checkInSummary = checks.length > 0
                ? checks.map(c => `- ${c.type}: ${c.valueText || c.valueNumber || (c.valueBool ? 'Да' : c.valueBool === false ? 'Нет' : 'Получен')}`).join('\n')
                : 'Сегодня чекинов не было.';

            // Calculate pending check-ins
            const rules = program.template.rules as any;
            const daySchedule = rules?.schedule?.find((s: any) => s.day === program.currentDay);
            let pendingSummary = '';

            if (daySchedule?.activities) {
                const completedTypes = checks.map(c => c.type);
                const pending = daySchedule.activities
                    .filter((a: any) => !completedTypes.includes(a.type))
                    .map((a: any) => `${a.type} (${a.time})`);

                if (pending.length > 0) {
                    pendingSummary = `\nОжидаемые чекины: ${pending.join(', ')}`;
                } else {
                    pendingSummary = `\nВсе чекины на сегодня выполнены.`;
                }
            }

            return `
Программа: ${program.template.name}
День: ${program.currentDay} из ${program.template.durationDays}
Дата старта: ${program.startDate.toLocaleDateString('ru-RU')}
Чекины сегодня:
${checkInSummary}${pendingSummary}
            `.trim();
        } catch (e) {
            console.error(e);
            return 'Ошибка получения данных программы.';
        }
    }

    /**
     * Get open tasks
     */
    private async getOpenTasks(patientId: string): Promise<string> {
        try {
            const tasks = await prisma.task.findMany({
                where: {
                    patientId,
                    status: { not: 'DONE' }
                },
                take: 5
            });

            if (tasks.length === 0) return 'Все задачи выполнены.';

            return tasks.map(t => `- [${t.priority}] ${t.title} (${t.status})`).join('\n');
        } catch (e) {
            return '';
        }
    }
}

// Singleton instance
export const aiService = new AIService();
