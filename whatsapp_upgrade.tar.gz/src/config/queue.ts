import { Queue, Worker, type Job, type Processor } from 'bullmq';
import { redis } from './redis.js';

// Default queue options
// Default queue options
export const defaultQueueOptions = {
    connection: redis as any,
    defaultJobOptions: {
        attempts: 3,
        backoff: {
            type: 'exponential' as const,
            delay: 1000,
        },
        removeOnComplete: 100,
        removeOnFail: 500,
    },
};

// Queue factory
export function createQueue(name: string): Queue {
    return new Queue(name, defaultQueueOptions);
}

// Worker factory
export function createWorker<T = unknown>(
    queueName: string,
    processor: Processor<T>,
    concurrency = 5
): Worker<T> {
    const worker = new Worker<T>(queueName, processor, {
        connection: redis as any,
        concurrency,
    });

    worker.on('completed', (job: Job<T>) => {
        console.log(`✅ Job ${job.id} completed in queue ${queueName}`);
    });

    worker.on('failed', (job: Job<T> | undefined, error: Error) => {
        console.error(`❌ Job ${job?.id} failed in queue ${queueName}:`, error.message);
    });

    worker.on('error', (error: Error) => {
        console.error(`❌ Worker error in queue ${queueName}:`, error.message);
    });

    return worker;
}

// Pre-defined queues for future modules
export const queues = {
    // Example: notifications, reminders, etc.
    // These will be created when modules are implemented
} as const;
// Re-export queues and workers
// export * from '../jobs/amoSync.worker.js';
